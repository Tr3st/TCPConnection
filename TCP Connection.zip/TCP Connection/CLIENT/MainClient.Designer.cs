﻿namespace ClientTCPSocket {
    partial class MainClient {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainClient));
            btnDisconnect = new Button();
            label1 = new Label();
            txtInvia = new TextBox();
            btnInvia = new Button();
            lblHost = new Label();
            groupConnect = new GroupBox();
            btnConnect = new Button();
            txtUsername = new TextBox();
            lblUsername = new Label();
            txtPort = new TextBox();
            lblPort = new Label();
            txtHost = new TextBox();
            groupSend = new GroupBox();
            btnBrowse = new Button();
            txtBox = new RichTextBox();
            groupView = new GroupBox();
            txtView = new RichTextBox();
            sMessOUT = new System.Media.SoundPlayer();
            sMessIN = new System.Media.SoundPlayer();
            sConnected = new System.Media.SoundPlayer();
            sDisconnected = new System.Media.SoundPlayer();
            groupConnect.SuspendLayout();
            groupSend.SuspendLayout();
            groupView.SuspendLayout();
            SuspendLayout();
            // 
            // btnDisconnect
            // 
            btnDisconnect.BackColor = SystemColors.ButtonFace;
            btnDisconnect.Cursor = Cursors.Hand;
            btnDisconnect.Enabled = false;
            btnDisconnect.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnDisconnect.Image = Properties.Resources.DisconnectPic;
            btnDisconnect.ImageAlign = ContentAlignment.MiddleLeft;
            btnDisconnect.Location = new Point(135, 151);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(110, 34);
            btnDisconnect.TabIndex = 0;
            btnDisconnect.Text = "Disconnect";
            btnDisconnect.TextAlign = ContentAlignment.MiddleRight;
            btnDisconnect.UseVisualStyleBackColor = false;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 264);
            label1.Name = "label1";
            label1.Size = new Size(79, 19);
            label1.TabIndex = 14;
            label1.Text = "Messaggio:";
            // 
            // txtInvia
            // 
            txtInvia.AllowDrop = true;
            txtInvia.Cursor = Cursors.IBeam;
            txtInvia.Enabled = false;
            txtInvia.Location = new Point(91, 264);
            txtInvia.Multiline = true;
            txtInvia.Name = "txtInvia";
            txtInvia.Size = new Size(362, 23);
            txtInvia.TabIndex = 13;
            txtInvia.KeyDown += txtInvio_KeyDown;
            // 
            // btnInvia
            // 
            btnInvia.BackColor = SystemColors.ButtonFace;
            btnInvia.Cursor = Cursors.Hand;
            btnInvia.Enabled = false;
            btnInvia.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnInvia.Image = Properties.Resources.SendPic;
            btnInvia.ImageAlign = ContentAlignment.MiddleLeft;
            btnInvia.Location = new Point(553, 265);
            btnInvia.Margin = new Padding(0);
            btnInvia.Name = "btnInvia";
            btnInvia.Size = new Size(58, 23);
            btnInvia.TabIndex = 15;
            btnInvia.Text = "Invia";
            btnInvia.TextAlign = ContentAlignment.MiddleRight;
            btnInvia.UseVisualStyleBackColor = false;
            btnInvia.Click += btnInvia_Click;
            // 
            // lblHost
            // 
            lblHost.AutoSize = true;
            lblHost.Location = new Point(34, 44);
            lblHost.Name = "lblHost";
            lblHost.Size = new Size(45, 19);
            lblHost.TabIndex = 16;
            lblHost.Text = "Host:";
            // 
            // groupConnect
            // 
            groupConnect.BackColor = SystemColors.ControlLight;
            groupConnect.Controls.Add(btnConnect);
            groupConnect.Controls.Add(txtUsername);
            groupConnect.Controls.Add(lblUsername);
            groupConnect.Controls.Add(txtPort);
            groupConnect.Controls.Add(btnDisconnect);
            groupConnect.Controls.Add(lblPort);
            groupConnect.Controls.Add(txtHost);
            groupConnect.Controls.Add(lblHost);
            groupConnect.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupConnect.Location = new Point(12, 12);
            groupConnect.Name = "groupConnect";
            groupConnect.Size = new Size(262, 196);
            groupConnect.TabIndex = 17;
            groupConnect.TabStop = false;
            groupConnect.Text = "Connect to the SMS gateway";
            // 
            // btnConnect
            // 
            btnConnect.BackColor = SystemColors.ButtonFace;
            btnConnect.Cursor = Cursors.Hand;
            btnConnect.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnConnect.Image = Properties.Resources.ConnectPic;
            btnConnect.ImageAlign = ContentAlignment.MiddleLeft;
            btnConnect.Location = new Point(18, 151);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(111, 34);
            btnConnect.TabIndex = 22;
            btnConnect.Text = "Connect";
            btnConnect.TextAlign = ContentAlignment.MiddleRight;
            btnConnect.UseVisualStyleBackColor = false;
            btnConnect.Click += btnConnetti_Click;
            // 
            // txtUsername
            // 
            txtUsername.Cursor = Cursors.IBeam;
            txtUsername.Location = new Point(85, 101);
            txtUsername.Name = "txtUsername";
            txtUsername.PlaceholderText = "Username";
            txtUsername.Size = new Size(103, 26);
            txtUsername.TabIndex = 21;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(1, 108);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(78, 19);
            lblUsername.TabIndex = 20;
            lblUsername.Text = "Username:";
            // 
            // txtPort
            // 
            txtPort.Cursor = Cursors.IBeam;
            txtPort.Location = new Point(85, 69);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(81, 26);
            txtPort.TabIndex = 19;
            txtPort.Text = "8080";
            // 
            // lblPort
            // 
            lblPort.AutoSize = true;
            lblPort.Location = new Point(38, 76);
            lblPort.Name = "lblPort";
            lblPort.Size = new Size(41, 19);
            lblPort.TabIndex = 18;
            lblPort.Text = "Port:";
            // 
            // txtHost
            // 
            txtHost.Cursor = Cursors.IBeam;
            txtHost.ForeColor = SystemColors.WindowText;
            txtHost.Location = new Point(85, 37);
            txtHost.Name = "txtHost";
            txtHost.Size = new Size(133, 26);
            txtHost.TabIndex = 17;
            txtHost.Text = "127.0.0.1";
            // 
            // groupSend
            // 
            groupSend.BackColor = SystemColors.ControlLight;
            groupSend.Controls.Add(btnBrowse);
            groupSend.Controls.Add(txtBox);
            groupSend.Controls.Add(btnInvia);
            groupSend.Controls.Add(label1);
            groupSend.Controls.Add(txtInvia);
            groupSend.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupSend.Location = new Point(13, 214);
            groupSend.Name = "groupSend";
            groupSend.Size = new Size(762, 293);
            groupSend.TabIndex = 18;
            groupSend.TabStop = false;
            groupSend.Text = "Send a SMS message";
            // 
            // btnBrowse
            // 
            btnBrowse.BackColor = SystemColors.ButtonFace;
            btnBrowse.Cursor = Cursors.Hand;
            btnBrowse.Image = Properties.Resources.clip;
            btnBrowse.ImageAlign = ContentAlignment.MiddleLeft;
            btnBrowse.Location = new Point(459, 264);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(91, 23);
            btnBrowse.TabIndex = 17;
            btnBrowse.Text = "Browse File";
            btnBrowse.TextAlign = ContentAlignment.MiddleRight;
            btnBrowse.UseVisualStyleBackColor = false;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // txtBox
            // 
            txtBox.ForeColor = SystemColors.WindowText;
            txtBox.Location = new Point(6, 22);
            txtBox.Name = "txtBox";
            txtBox.ReadOnly = true;
            txtBox.Size = new Size(750, 228);
            txtBox.TabIndex = 16;
            txtBox.Text = "";
            txtBox.ZoomFactor = 1.6F;
            // 
            // groupView
            // 
            groupView.BackColor = SystemColors.ControlLight;
            groupView.Controls.Add(txtView);
            groupView.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupView.Location = new Point(282, 12);
            groupView.Name = "groupView";
            groupView.Size = new Size(493, 196);
            groupView.TabIndex = 19;
            groupView.TabStop = false;
            groupView.Text = "View events";
            // 
            // txtView
            // 
            txtView.BackColor = SystemColors.Window;
            txtView.Location = new Point(6, 22);
            txtView.Name = "txtView";
            txtView.ReadOnly = true;
            txtView.ScrollBars = RichTextBoxScrollBars.ForcedBoth;
            txtView.Size = new Size(481, 163);
            txtView.TabIndex = 0;
            txtView.Text = "";
            txtView.WordWrap = false;
            // 
            // sMessOUT
            // 
            sMessOUT.LoadTimeout = 10000;
            sMessOUT.SoundLocation = "../../../Resources/chat_message_outbound.wav";
            sMessOUT.Stream = null;
            sMessOUT.Tag = null;
            // 
            // sMessIN
            // 
            sMessIN.LoadTimeout = 10000;
            sMessIN.SoundLocation = "../../../Resources/chat_message_inbound.wav";
            sMessIN.Stream = null;
            sMessIN.Tag = null;
            // 
            // sConnected
            // 
            sConnected.LoadTimeout = 10000;
            sConnected.SoundLocation = "../../../Resources/connected.wav";
            sConnected.Stream = null;
            sConnected.Tag = null;
            // 
            // sDisconnected
            // 
            sDisconnected.LoadTimeout = 10000;
            sDisconnected.SoundLocation = "../../../Resources/disconnected.wav";
            sDisconnected.Stream = null;
            sDisconnected.Tag = null;
            // 
            // MainClient
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(787, 515);
            Controls.Add(groupView);
            Controls.Add(groupSend);
            Controls.Add(groupConnect);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainClient";
            Text = "Client";
            FormClosing += Form1_FormClosing;
            groupConnect.ResumeLayout(false);
            groupConnect.PerformLayout();
            groupSend.ResumeLayout(false);
            groupSend.PerformLayout();
            groupView.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        public System.Media.SoundPlayer sMessOUT;
        public System.Media.SoundPlayer sMessIN;
        private Button btnDisconnect;
        private Label label1;
        public TextBox txtInvia;
        private Button btnInvia;
        private Label lblHost;
        private GroupBox groupConnect;
        public TextBox txtUsername;
        private Label lblUsername;
        public TextBox txtPort;
        private Label lblPort;
        public TextBox txtHost;
        private GroupBox groupSend;
        private GroupBox groupView;
        private RichTextBox txtBox;
        private RichTextBox txtView;
        private Button btnConnect;
        public System.Media.SoundPlayer sConnected;
        public System.Media.SoundPlayer sDisconnected;
        private Button btnBrowse;
    }
}
