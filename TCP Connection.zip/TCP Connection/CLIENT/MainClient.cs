using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Runtime.InteropServices;
using System.Net.NetworkInformation;
using System.Linq.Expressions;

namespace ClientTCPSocket {
    public partial class MainClient : Form {
        public MainClient() {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        private const int DIMBUF = 8192;
        private const int NPORTE = 10;

        private bool clientConnected = false;

        private IPAddress IPServer;
        private int porta;

        private IPEndPoint ServerSocket;
        private Socket ClientSocket;
        private String MACAddress;
        private Thread thrReceive;


        private void btnConnetti_Click(object sender, EventArgs e) {
            ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ClientSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.DontLinger, true);
            clientConnected = ClientSocket.Connected;

            if (!clientConnected) {
                if (txtUsername.Text != "" && txtPort.Text != "" && txtHost.Text != "") {
                    try {
                        IPServer = IPAddress.Parse(txtHost.Text);
                        porta = Convert.ToInt32(txtPort.Text);
                        MACAddress = getMACAddress();
                        ServerSocket = new IPEndPoint(IPServer, porta);

                        ClientSocket.Connect(ServerSocket);

                        byte[] buffer = new byte[DIMBUF];
                        buffer = Encoding.ASCII.GetBytes(txtUsername.Text);
                        ClientSocket.Send(buffer);

                        thrReceive = new Thread(() => ReceiveMessage());
                        thrReceive.Start();

                        ConsoleW(TextMessage.clientConnected, Color.Green);

                        sConnected.Play();
                        btnConnect.Enabled = false;
                        btnDisconnect.Enabled = true;
                        btnInvia.Enabled = true;
                        txtInvia.Enabled = true;
                    } catch (SocketException ex) {
                        ViewW(ex.Message);
                    } catch (FormatException ex) {
                        ViewW(ex.Message);
                    } catch (ArgumentNullException ex) {
                        ViewW(ex.Message);
                        ConsoleW(TextMessage.emptyField, Color.Crimson);
                    } catch (OutOfMemoryException ex) {
                        ViewW(ex.Message);
                    }
                } else { ConsoleW(TextMessage.emptyField); }
            }
        }
        private void btnDisconnect_Click(object sender, EventArgs e) {
            StopClient();
            ConsoleW(TextMessage.clientDisconnect);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            StopClient();
        }
        private void btnInvia_Click(object sender, EventArgs e) {
            if (ClientSocket.Connected && txtInvia.Text != "") {
                byte[] buffer = new byte[DIMBUF];
                String message = txtInvia.Text.ToString() + TextMessage.nl;
                sMessOUT.Play();
                buffer = Encoding.ASCII.GetBytes(message);
                ClientSocket.Send(buffer);


                txtInvia.Text = "";
                ConsoleW("Tu: " + message.Replace(TextMessage.nl, ""));
            }
        }
        private void ReceiveMessage() {
            while (ClientSocket.Connected) {
                try {
                    byte[] buffer = new byte[DIMBUF];
                    String messaggioRCV;

                    ClientSocket.Receive(buffer);
                    messaggioRCV = Encoding.ASCII.GetString(buffer);

                    if (messaggioRCV.Contains(TextMessage.nl)) {
                        sMessIN.Play();
                        ConsoleW("[SERVER]: " + messaggioRCV);
                    }

                    if (messaggioRCV.Contains(TextMessage.serverDisconnectEvent)) {
                        ConsoleW(TextMessage.serverDisconnect, Color.Crimson);
                        StopClient();
                        btnDisconnect.Enabled = true;
                        clientConnected = false;
                    }

                } catch (Exception e) {
                    ViewW(e.Message);
                }
            }
        }
        public void ViewW(String mess) {
            txtView.Text += DateTime.Now.ToString("MM/dd/yyyy HH:mm ") + mess + TextMessage.nl;
        }
        public void ConsoleW(String mess, Color c) {
            txtBox.SelectionColor = c;
            txtBox.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }
        public void ConsoleW(String mess) {
            txtBox.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }


        private void txtInvio_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.Enter) {
                e.Handled = true;
                e.SuppressKeyPress = true;
                btnInvia.PerformClick();
            }
        }
        private void StopClient() {
            if (ClientSocket != null && ClientSocket.Connected) {
                try {
                    ClientSocket.Send(Encoding.ASCII.GetBytes(TextMessage.clientDisconnectEvent));

                    ClientSocket.Shutdown(SocketShutdown.Both);
                    ClientSocket.Disconnect(true);
                    ClientSocket.Close();
                    ClientSocket.Dispose();
                } catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            }
            sDisconnected.Play();
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            btnInvia.Enabled = false;
            txtInvia.Enabled = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e) {

        }

        private String getMACAddress() {
            try{
                String macadd = String.Empty;
                foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces()) {
                    if (n.OperationalStatus == OperationalStatus.Up) {
                        macadd += n.GetPhysicalAddress().ToString();
                        break;
                    }
                }
                return macadd;
            }
            catch (Exception e) {
                return null;
                ViewW(e.Message);
            }
        }
    }
}
