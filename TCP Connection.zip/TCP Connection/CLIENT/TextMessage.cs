﻿namespace ClientTCPSocket {
    public class TextMessage {

        //Terminatore di stringa.
        public static readonly String nl = "\r\n";

        //Messaggi all'avviamento e spegnimento del Server.
        public static readonly String clientConnected = "Sucessfully connected to the Server...";
        public static readonly String clientDisconnect = "Disconnected from the Server!";
        public static readonly String serverDisconnect = "The host has disconnected from you.";

        //Empty Field
        public static readonly String emptyField = "[!]None of the fields can be empty.";

        //Questi due parametri devono essere gli stessi su Client e Server.
        public static readonly String clientDisconnectEvent = "_CLIENT_DISCONNECT_EVENT_";
        public static readonly String serverDisconnectEvent = "_THE_SERVER_STOPPED_";

    }
}
