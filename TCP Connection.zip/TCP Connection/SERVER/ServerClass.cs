﻿using System.Net.Sockets;
using System.Net;
using System.Text;
#pragma warning disable SYSLIB0006

namespace ServerTCPSocket {
    internal class ServerClass {

        private bool SEVERON = true;
        private int numberConnectedClient = 0;

        private MainServer puntaForm = null;
        private ChatClass puntaChat = null;

        private const int DIMBUF = 8192; //8K

        private Socket ServerSocket;
        private IPEndPoint localEndPoint;
        private Thread thrServerPool;
        public List<InfoClient> listaClient = null;

        public ServerClass(MainServer pf) {
            puntaForm = pf;
            puntaChat = new ChatClass(this);
        }

        public void startServer(int porta, int maxConnessioni) {
            listaClient = new List<InfoClient>();
            thrServerPool = new Thread(() => Polling(porta, maxConnessioni));
            thrServerPool.Start();
        }
        private void Polling(int porta, int maxConnessioni) {
            ServerSocket = BuildSocket(porta);
            puntaForm.TabWrite(TextMessage.serverStarted);
            puntaForm.TabWrite(TextMessage.serverCommandUsage);
            if (ServerSocket != null) {
                while (SEVERON) {
                    if (listaClient == null || listaClient.Count < maxConnessioni) {
                        try {
                            InfoClient handler = new InfoClient(ServerSocket.Accept(), StatoClient.Attivo, numberConnectedClient++);

                            byte[] buffer = new byte[DIMBUF];
                            handler.ClientSocketDescriptor.Receive(buffer);
                            handler.ClientUsername = Encoding.ASCII.GetString(buffer);
                            /*
                            bool found = false;
                            if(listaClient != null) {
                                for(int i = 0; i < listaClient.Count; i++) {
                                    if(listaClient[i].ClientSocketDescriptor.RemoteEndPoint.Equals(handler.ClientSocketDescriptor.RemoteEndPoint)) {
                                        MessageBox.Show("RIPRESO CLIENT ESISTENTE");
                                        listaClient[i] = new InfoClient(handler.ClientSocketDescriptor, StatoClient.Attivo, handler.ClientID);
                                        found = true;
                                    }
                                }
                            } else {
                                listaClient = new List<InfoClient>();
                            }
                            if(!found) {
                                MessageBox.Show("NUOVO CLIENT");
                                listaClient.Add(handler);
                            }
                            */
                            handler.RicezioneThread = new Thread(() => ReceiveMessage(handler));
                            handler.RicezioneThread.Start();

                            listaClient.Add(handler);

                            ListViewItem client = new ListViewItem();
                            client.Text = handler.ClientIndirizzoIP.ToString() + ":" + handler.ClientPorta.ToString();
                            client.SubItems.Add(handler.ClientUsername);
                            client.SubItems.Add(handler.ConnectionDate);
                            puntaForm.lstClient.Items.Add(client);

                            puntaForm.TabWrite((handler.ClientIndirizzoIP.ToString() + ":" + handler.ClientPorta.ToString()) + " has just connected.", Color.Green);
                        } catch (SocketException e) { 
                            puntaForm.TabWrite(e.Message.ToString(), Color.Crimson); 
                        }
                        catch (Exception e) { 
                            puntaForm.TabWrite(e.Message.ToString(), Color.Crimson); 
                        }
                    }
                }
            }
        }
        
        private void ReceiveMessage(InfoClient handler) {
            while (SEVERON) {
                if (handler.statoC == StatoClient.Attivo && handler.ClientSocketDescriptor != null && handler.ClientSocketDescriptor.Available != 0) {
                    byte[] buffer = new byte[DIMBUF];
                    String messaggioRCV;

                    handler.ClientSocketDescriptor.Receive(buffer);
                    messaggioRCV = Encoding.ASCII.GetString(buffer);

                    if (messaggioRCV.Contains(TextMessage.nl))
                        puntaChat.receiveClient(puntaForm, handler, messaggioRCV);

                    if (messaggioRCV.Contains(TextMessage.clientDisconnectEvent)) {
                        disconnectClient(handler);
                    }
                }
            }
        }

        public void sendStrictMessage(String messaggio, InfoClient h) {
            if(h.statoC == StatoClient.Attivo) {
                bool found = false;
                for(int i = 0; i < listaClient.Count; i++) {
                    if(listaClient[i].ClientPorta == h.ClientPorta) {
                        byte[] buffer = new byte[DIMBUF];
                        buffer = Encoding.ASCII.GetBytes(messaggio);
                        listaClient[i].ClientSocketDescriptor.Send(buffer);
                        found = true;
                    }

                }
                if(found)
                    puntaForm.ClientWrite(messaggio.Replace(TextMessage.nl, ""));
                else
                    puntaForm.TabWrite(TextMessage.wrongClientPort);
            }
        }
        public void sendMessage(String messaggioSND) {
            if(listaClient.Count > 0) {
                byte[] buffer = new byte[DIMBUF];
                messaggioSND += TextMessage.nl;
                if(puntaForm.tabSMS.SelectedTab.Equals(puntaForm.tabConsole)) {
                    for(int i = 0; i < listaClient.Count; i++) {
                        if(listaClient[i].ClientSocketDescriptor.Connected && listaClient[i].statoC == StatoClient.Attivo) {
                            buffer = Encoding.ASCII.GetBytes(messaggioSND);
                            listaClient[i].ClientSocketDescriptor.Send(buffer);
                        }
                    }
                    puntaForm.TabWrite("[BROADCAST]: " + messaggioSND.Replace(TextMessage.nl, ""));
                } else {
                    TabPage currentTab = puntaForm.tabSMS.SelectedTab;
                    for(int i = 0; i < listaClient.Count; i++)
                        try {
                            if(listaClient[i].tabClient.Equals(currentTab))
                                sendStrictMessage(messaggioSND, listaClient[i]);
                        } catch(NullReferenceException) { }
                } 
            } else { puntaForm.TabWrite(TextMessage.noClientConnected); }
        }

        private Socket BuildSocket(int p) {
            try {
                localEndPoint = new IPEndPoint(IPAddress.Any, p);

                var tmpSocket = new Socket(localEndPoint.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                tmpSocket.Bind(localEndPoint);
                tmpSocket.Listen();

                return tmpSocket;
            } catch (Exception) {
                return null;
            }
        }
        public void StopServer() {
            try {
                SEVERON = false;
                puntaForm.lstClient.Items.Clear();
                numberConnectedClient = 0;

                if (thrServerPool != null)
                    thrServerPool = null;

                if (listaClient != null && listaClient.Count > 0) {
                    for (int i = 0; i < listaClient.Count; i++) {
                        listaClient[i].ClientSocketDescriptor.Send(Encoding.ASCII.GetBytes(TextMessage.serverDisconnectEvent));
                        listaClient[i].ClientSocketDescriptor.Shutdown(SocketShutdown.Both);
                        listaClient[i].ClientSocketDescriptor.Close();
                        listaClient[i].statoC = StatoClient.Chiuso;
                        listaClient[i].RicezioneThread = null;
                    }
                    listaClient.Clear();
                }
                if (ServerSocket != null) {
                    ServerSocket.Close();
                    ServerSocket.Dispose();
                }
                puntaForm.TabWrite(TextMessage.serverStopped);
            } catch (Exception e) { puntaForm.TabWrite(e.Message.ToString(), Color.Crimson); }
        }
        public void disconnectClient(InfoClient handler) {
            puntaForm.TabWrite(handler.ClientIndirizzoIP.ToString() + ":" + handler.ClientPorta.ToString() + " disconnected!", Color.Crimson);

            puntaForm.lstClient.Items.RemoveAt(handler.ClientID);
            listaClient.RemoveAt(handler.ClientID);

            if (handler.txtClient != null) 
                puntaForm.ClientWrite("This client has disconnected :,(", handler.txtClient);
            
            
            for (int i = handler.ClientID; i < listaClient.Count; i++)
                listaClient[i].ClientID--;
            

            numberConnectedClient--;
            handler.statoC = StatoClient.Chiuso;
            handler.ClientSocketDescriptor.Shutdown(SocketShutdown.Both);
            handler.ClientSocketDescriptor.Close();
        }
        
    }
}

