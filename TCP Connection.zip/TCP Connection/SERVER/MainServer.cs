using System.Windows.Forms;

namespace ServerTCPSocket {
    public partial class MainServer :Form {
        public MainServer() {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        Point _imageLocation = new Point(20, 4);
        Point _imgHitArea = new Point(20, 4);
        Image closeImage;

        private const int NPORTE = 10;
        private const int NMAXCLIENT = 50;

        private bool buttonState = false;

        private ServerClass puntaServer = null;
        private ChatClass puntaChat = null;

        private void MainServer_Load(object sender, EventArgs e) {

            closeImage = Properties.Resources.close;
            tabSMS.Padding = new Point(20, 4);

            comboNClient.Text = comboNClient.Items[0].ToString();
            buttonState = false;

            puntaServer = new ServerClass(this);
            puntaChat = new ChatClass(puntaServer);
        }
        private void btnInvio_Click(object sender, EventArgs e) {
            String messaggioCasella = txtInvio.Text.ToString();
            if(messaggioCasella != null && messaggioCasella != "") {
                puntaServer.sendMessage(messaggioCasella);
                messOUT.Play();
            }
            txtInvio.Text = "";
        }
        private void btnAvvia_Click(object sender, EventArgs e) {
            if(buttonState) {
                //SPENGI
                btnAvvia.Text = "Avvia";
                TabWrite("Stopping...");
                OnOffSett(false);

                puntaServer.StopServer();
                pic.Image = Properties.Resources.OffButton;
            } else {
                //ACCENDI
                btnAvvia.Text = "Spegni";
                TabWrite("Starting...");
                OnOffSett(true);

                puntaServer.startServer(Convert.ToInt32(txtPort.Text), Convert.ToInt32(comboNClient.Text.ToString()));
                pic.Image = Properties.Resources.OnButton;
            }
        }

        public void ClientWrite(String mess, RichTextBox txtClient) {
            txtClient.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }
        public void ClientWrite(String mess) {
            RichTextBox tmp = tabSMS.SelectedTab.Controls[0] as RichTextBox;
            tmp.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }
        public void TabWrite(String mess, Color c) {
            txtConsole.SelectionColor = c;
            txtConsole.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }
        public void TabWrite(String mess) {
            txtConsole.SelectedText += "<" + DateTime.Now.ToShortTimeString() + "> " + mess + TextMessage.nl;
        }
        private void txtInvio_KeyDown(object sender, KeyEventArgs e) {
            if(e.KeyCode == Keys.Enter) {
                e.Handled = true;
                e.SuppressKeyPress = true;
                btnInvia.PerformClick();
            }
        }

        private void OnOffSett(bool status) {
            txtInvio.Enabled = status;
            btnInvia.Enabled = status;
            buttonState = status;
            txtInvio.Text = "";
        }

        private void MainServer_FormClosing(object sender, FormClosingEventArgs e) {
            puntaServer.StopServer();
        }

        private void lstClientIP_MouseDoubleClick_1(object sender, MouseEventArgs e) {
            ListViewItem item = lstClient.HitTest(e.X, e.Y).Item;
            int index = item.Index;
            if(item != null) {
                for(int i = 0; i < puntaServer.listaClient.Count; i++) {
                    if(puntaServer.listaClient[i].ClientID.Equals(index))
                        puntaChat.receiveClient(this, puntaServer.listaClient[i], "");
                }
            }
        }

        private void tabSMS_DrawItem(object sender, DrawItemEventArgs e) {
            Image img = new Bitmap(closeImage);
            Rectangle r = e.Bounds;
            r = tabSMS.GetTabRect(e.Index);
            r.Offset(2, 2);
            Brush TitleBrush = new SolidBrush(Color.Black);
            Font f = this.Font;
            String title = tabSMS.TabPages[e.Index].Text;
            e.Graphics.DrawString(title, f, TitleBrush, new PointF(r.X, r.Y));
            e.Graphics.DrawImage(img, new Point(r.X + (tabSMS.GetTabRect(e.Index).Width - _imageLocation.X), _imageLocation.Y));
        }

        private void tabSMS_MouseClick(object sender, MouseEventArgs e) {
            TabControl tabControl = (TabControl)sender;
            Point p = e.Location;
            int _tabWidth = 0;
            _tabWidth = tabSMS.GetTabRect(tabControl.SelectedIndex).Width - (_imgHitArea.X);
            Rectangle r = tabSMS.GetTabRect(tabControl.SelectedIndex);
            r.Offset(_tabWidth, _imgHitArea.Y);
            r.Width = 16;
            r.Height = 16;
            if(tabSMS.SelectedIndex >= 1) {
                if(r.Contains(p)) {
                    TabPage tabPage = (TabPage)tabControl.TabPages[tabControl.SelectedIndex];
                    tabControl.TabPages.Remove(tabPage);
                }
            }
        }
    }
}
