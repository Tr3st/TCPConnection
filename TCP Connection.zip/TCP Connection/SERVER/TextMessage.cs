﻿namespace ServerTCPSocket {
    public class TextMessage {
        public static readonly String nl = "\r\n";

        //DEL SERVER
        public static readonly String serverStarted = "Server started correctly.";
        public static readonly String serverStopped = "Server stopped.";
        public static readonly String serverCommandUsage = "Use /help for commands list.";

        //EVENTI DI STATO
        public static readonly String clientDisconnectEvent = "_CLIENT_DISCONNECT_EVENT_";
        public static readonly String serverDisconnectEvent = "_THE_SERVER_STOPPED_";

        //DI ERRORE
        public static readonly String noClientConnected = "[!]No client connected!";
        public static readonly String wrongClientPort = "[!]No Client found with this port.";
        public static readonly String wrongPort = "[!]Porta errata!";
        public static readonly String wrongCommand = "[!]Wrong Command, type /help for the list.";
    }
}
