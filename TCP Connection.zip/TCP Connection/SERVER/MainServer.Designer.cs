﻿using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Forms;

namespace ServerTCPSocket {
    partial class MainServer {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainServer));
            lblPort = new Label();
            lbl_NClient = new Label();
            btnAvvia = new Button();
            txtInvio = new TextBox();
            label1 = new Label();
            btnInvia = new Button();
            groupBox1 = new GroupBox();
            pic = new PictureBox();
            comboNClient = new ComboBox();
            txtPort = new TextBox();
            groupBox2 = new GroupBox();
            tabSMS = new TabControl();
            tabConsole = new TabPage();
            txtConsole = new RichTextBox();
            groupBox3 = new GroupBox();
            lstClient = new ListView();
            colIP = new ColumnHeader();
            colUsername = new ColumnHeader();
            colConnection = new ColumnHeader();
            messOUT = new System.Media.SoundPlayer();
            messIN = new System.Media.SoundPlayer();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic).BeginInit();
            groupBox2.SuspendLayout();
            tabSMS.SuspendLayout();
            tabConsole.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // lblPort
            // 
            lblPort.AutoSize = true;
            lblPort.Location = new Point(62, 48);
            lblPort.Name = "lblPort";
            lblPort.Size = new Size(41, 19);
            lblPort.TabIndex = 0;
            lblPort.Text = "Port:";
            // 
            // lbl_NClient
            // 
            lbl_NClient.AutoSize = true;
            lbl_NClient.Location = new Point(22, 80);
            lbl_NClient.Name = "lbl_NClient";
            lbl_NClient.Size = new Size(81, 19);
            lbl_NClient.TabIndex = 0;
            lbl_NClient.Text = "Max client:";
            // 
            // btnAvvia
            // 
            btnAvvia.BackColor = SystemColors.ControlLight;
            btnAvvia.Cursor = Cursors.Hand;
            btnAvvia.FlatStyle = FlatStyle.Flat;
            btnAvvia.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAvvia.ForeColor = SystemColors.ControlText;
            btnAvvia.Location = new Point(554, 147);
            btnAvvia.Name = "btnAvvia";
            btnAvvia.Size = new Size(139, 53);
            btnAvvia.TabIndex = 0;
            btnAvvia.Text = "Avvia";
            btnAvvia.UseVisualStyleBackColor = false;
            btnAvvia.Click += btnAvvia_Click;
            // 
            // txtInvio
            // 
            txtInvio.Enabled = false;
            txtInvio.Location = new Point(91, 317);
            txtInvio.Name = "txtInvio";
            txtInvio.PlaceholderText = "Text here...";
            txtInvio.Size = new Size(508, 26);
            txtInvio.TabIndex = 0;
            txtInvio.KeyDown += txtInvio_KeyDown;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 324);
            label1.Name = "label1";
            label1.Size = new Size(79, 19);
            label1.TabIndex = 0;
            label1.Text = "Messaggio:";
            // 
            // btnInvia
            // 
            btnInvia.BackColor = SystemColors.ControlLight;
            btnInvia.Cursor = Cursors.Hand;
            btnInvia.Enabled = false;
            btnInvia.FlatStyle = FlatStyle.Popup;
            btnInvia.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnInvia.ForeColor = SystemColors.ControlText;
            btnInvia.Location = new Point(605, 317);
            btnInvia.Name = "btnInvia";
            btnInvia.Size = new Size(94, 26);
            btnInvia.TabIndex = 0;
            btnInvia.Text = "Invio";
            btnInvia.UseVisualStyleBackColor = false;
            btnInvia.Click += btnInvio_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Wheat;
            groupBox1.Controls.Add(pic);
            groupBox1.Controls.Add(comboNClient);
            groupBox1.Controls.Add(txtPort);
            groupBox1.Controls.Add(lbl_NClient);
            groupBox1.Controls.Add(lblPort);
            groupBox1.Controls.Add(btnAvvia);
            groupBox1.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(709, 215);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Server options";
            // 
            // pic
            // 
            pic.BackColor = Color.Transparent;
            pic.BackgroundImageLayout = ImageLayout.None;
            pic.Image = Properties.Resources.OffButton;
            pic.InitialImage = null;
            pic.Location = new Point(460, 124);
            pic.Name = "pic";
            pic.Size = new Size(88, 85);
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.TabIndex = 0;
            pic.TabStop = false;
            // 
            // comboNClient
            // 
            comboNClient.Cursor = Cursors.Hand;
            comboNClient.FormattingEnabled = true;
            comboNClient.Items.AddRange(new object[] { "10", "20", "30", "40", "50", "60", "70", "80", "90", "100" });
            comboNClient.Location = new Point(109, 73);
            comboNClient.Name = "comboNClient";
            comboNClient.Size = new Size(67, 26);
            comboNClient.TabIndex = 0;
            // 
            // txtPort
            // 
            txtPort.Location = new Point(109, 41);
            txtPort.Name = "txtPort";
            txtPort.PlaceholderText = "8080";
            txtPort.Size = new Size(100, 26);
            txtPort.TabIndex = 0;
            txtPort.Text = "8080";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Wheat;
            groupBox2.BackgroundImageLayout = ImageLayout.None;
            groupBox2.Controls.Add(tabSMS);
            groupBox2.Controls.Add(txtInvio);
            groupBox2.Controls.Add(btnInvia);
            groupBox2.Controls.Add(label1);
            groupBox2.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox2.Location = new Point(12, 233);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(709, 349);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Console and SMS messages";
            // 
            // tabSMS
            // 
            tabSMS.Alignment = TabAlignment.Bottom;
            tabSMS.Controls.Add(tabConsole);
            tabSMS.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabSMS.Location = new Point(6, 22);
            tabSMS.Name = "tabSMS";
            tabSMS.SelectedIndex = 0;
            tabSMS.Size = new Size(697, 292);
            tabSMS.TabIndex = 0;
            tabSMS.DrawItem += tabSMS_DrawItem;
            tabSMS.MouseClick += tabSMS_MouseClick;
            // 
            // tabConsole
            // 
            tabConsole.BorderStyle = BorderStyle.Fixed3D;
            tabConsole.Controls.Add(txtConsole);
            tabConsole.Location = new Point(4, 4);
            tabConsole.Name = "tabConsole";
            tabConsole.Padding = new Padding(3);
            tabConsole.Size = new Size(689, 261);
            tabConsole.TabIndex = 0;
            tabConsole.Text = "CONSOLE";
            tabConsole.UseVisualStyleBackColor = true;
            // 
            // txtConsole
            // 
            txtConsole.Location = new Point(-2, -2);
            txtConsole.Name = "txtConsole";
            txtConsole.ReadOnly = true;
            txtConsole.ScrollBars = RichTextBoxScrollBars.Vertical;
            txtConsole.Size = new Size(688, 259);
            txtConsole.TabIndex = 1;
            txtConsole.Text = "";
            txtConsole.ZoomFactor = 1.2F;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Wheat;
            groupBox3.Controls.Add(lstClient);
            groupBox3.Font = new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox3.Location = new Point(727, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(359, 570);
            groupBox3.TabIndex = 0;
            groupBox3.TabStop = false;
            groupBox3.Text = "Client lists";
            // 
            // lstClient
            // 
            lstClient.Activation = ItemActivation.OneClick;
            lstClient.Columns.AddRange(new ColumnHeader[] { colIP, colUsername, colConnection });
            lstClient.FullRowSelect = true;
            lstClient.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            lstClient.Location = new Point(6, 25);
            lstClient.MultiSelect = false;
            lstClient.Name = "lstClient";
            lstClient.Size = new Size(347, 541);
            lstClient.TabIndex = 0;
            lstClient.UseCompatibleStateImageBehavior = false;
            lstClient.View = View.Details;
            lstClient.MouseDoubleClick += lstClientIP_MouseDoubleClick_1;
            // 
            // colIP
            // 
            colIP.Text = "IP Address";
            colIP.Width = 120;
            // 
            // colUsername
            // 
            colUsername.Text = "Username";
            colUsername.Width = 100;
            // 
            // colConnection
            // 
            colConnection.Text = "Connection Date";
            colConnection.Width = 150;
            // 
            // messOUT
            // 
            messOUT.LoadTimeout = 100000;
            messOUT.SoundLocation = "../../../Resources/chat_message_outbound.wav";
            messOUT.Stream = null;
            messOUT.Tag = null;
            // 
            // messIN
            // 
            messIN.LoadTimeout = 10000;
            messIN.SoundLocation = "../../../Resources/chat_message_inbound.wav";
            messIN.Stream = null;
            messIN.Tag = null;
            // 
            // MainServer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleGoldenrod;
            ClientSize = new Size(1091, 585);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainServer";
            Text = "Server";
            FormClosing += MainServer_FormClosing;
            Load += MainServer_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            tabSMS.ResumeLayout(false);
            tabConsole.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        public System.Media.SoundPlayer messOUT;
        public System.Media.SoundPlayer messIN;
        private Label label1;
        private Label lblPort;
        public ComboBox txtPorta;
        private Label lbl_NClient;
        private Button btnAvvia;
        public TextBox txtInvio;
        private Button btnInvia;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        public TabControl tabSMS;
        public TabPage tabConsole;
        private TextBox txtPort;
        private ComboBox comboNClient;
        private PictureBox pic;
        public ListView lstClient;
        private ColumnHeader colIP;
        private ColumnHeader colUsername;
        private RichTextBox txtConsole;
        private ColumnHeader colConnection;
    }
}
