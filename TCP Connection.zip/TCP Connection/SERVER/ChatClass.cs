﻿namespace ServerTCPSocket {
    internal class ChatClass {

        MainServer puntaForm = null;
        ServerClass puntaServer = null;

        public ChatClass(ServerClass ps) {
            puntaServer = ps;
        }

        private void creaBox(InfoClient handler) {
            RichTextBox txtChat = new RichTextBox();
            txtChat.Location = new Point(-2, -2);
            txtChat.Multiline = true;
            txtChat.Name = "textChat" + handler.ClientID;
            txtChat.ReadOnly = true;
            txtChat.ScrollBars = RichTextBoxScrollBars.Vertical;
            txtChat.Size = new Size(688, 259);
            txtChat.TabIndex = 0;

            TabPage tabChat = new TabPage();
            tabChat.BorderStyle = BorderStyle.Fixed3D;
            tabChat.Controls.Add(txtChat);
            tabChat.Location = new Point(4, 4);
            tabChat.Name = "tabChat" + handler.ClientID;
            tabChat.Padding = new Padding(3);
            tabChat.Size = new Size(689, 264);
            tabChat.TabIndex = 0;
            tabChat.Text = handler.ClientUsername;
            tabChat.UseVisualStyleBackColor = true;

            handler.txtClient = txtChat;
            handler.tabClient = tabChat;
        }

        public void receiveClient(MainServer pf, InfoClient handler, String messaggioRCV) {
            puntaForm = pf;
            if (handler.txtClient == null || handler.tabClient == null) {
                creaBox(handler);
                puntaForm.tabSMS.Invoke(new Action(() => puntaForm.tabSMS.Controls.Add(handler.tabClient)));
            } else {
                bool trovato = false;
                for (int i = 0; i < puntaForm.tabSMS.Controls.Count; i++) {
                    if (puntaForm.tabSMS.Controls[i].Name.Equals("tabChat" + handler.ClientID)) {
                        trovato = true;
                    }
                }
                if (!trovato) {
                    puntaForm.tabSMS.Invoke(new Action(() => puntaForm.tabSMS.Controls.Add(handler.tabClient)));
                }
            }
            if(messaggioRCV != "") {
                puntaForm.ClientWrite(messaggioRCV, handler.txtClient);
                puntaForm.messIN.Play();
            }
        }
    }
}
