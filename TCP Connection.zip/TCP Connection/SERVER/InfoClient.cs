﻿using System.Net;
using System.Net.Sockets;

namespace ServerTCPSocket {

    public enum StatoClient {
        Attivo,
        Chiuso,
        Sospeso
    }

    public class InfoClient {

        
        public Socket ClientSocketDescriptor = null;
        public Thread RicezioneThread = null;
        public StatoClient statoC = StatoClient.Sospeso;
        public IPAddress ClientIndirizzoIP;
        public int ClientPorta;
        public String ClientUsername = null;
        public int ClientID;
        public String ConnectionDate;

        public TabPage tabClient = null;
        public RichTextBox txtClient = null;

        public InfoClient() { }
        public InfoClient(Socket MioSocket, StatoClient MioStato, int numcl) {
            this.ClientSocketDescriptor = MioSocket;
            this.statoC = MioStato;
            this.ClientID = numcl;
            this.ConnectionDate = DateTime.Now.ToString("MM/dd/yyyy HH:mm ");

            this.ClientIndirizzoIP = ((IPEndPoint)(MioSocket.RemoteEndPoint)).Address;
            this.ClientPorta = ((IPEndPoint)(MioSocket.RemoteEndPoint)).Port;

        }
        public void stampaInfo() {
            MessageBox.Show("Username ->" + ClientUsername + TextMessage.nl
                + "ID -> " + ClientID.ToString() + TextMessage.nl
                + "Connection Date ->" + ConnectionDate + TextMessage.nl
                + "Address -> " + ClientIndirizzoIP.ToString() + TextMessage.nl
                + "Port -> " + ClientPorta.ToString() + TextMessage.nl);
        }
    }
}
